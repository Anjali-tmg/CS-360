
package com.example.anjalieventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Connect Java variables to the login screen.
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateLogin = findViewById(R.id.buttonCreateLogin);

        // Open the SQLite database.
        databaseHelper = new DatabaseHelper(this);

        // Check the username and password when Login is clicked.
        buttonLogin.setOnClickListener(view -> loginUser());

        // Create a new account when the user clicks this button.
        buttonCreateLogin.setOnClickListener(view -> createUser());
    }

    private void loginUser() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Please enter username and password",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Verify the login information stored in SQLite.
        if (databaseHelper.checkUser(username, password)) {
            Toast.makeText(this,
                    "Login successful",
                    Toast.LENGTH_SHORT).show();

            // Open the event management screen.
            Intent intent = new Intent(this, EventsActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this,
                    "Incorrect username or password",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void createUser() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Please enter username and password",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Save the new account in the SQLite database.
        boolean created = databaseHelper.addUser(username, password);

        if (created) {
            Toast.makeText(this,
                    "Account created successfully. Please log in.",
                    Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this,
                    "Unable to create account. Username may already exist.",
                    Toast.LENGTH_LONG).show();
        }
    }
}
