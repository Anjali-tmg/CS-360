
package com.example.anjalieventtrackingapp;

import android.Manifest;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class EventsActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private GridLayout eventsGrid;
    private EditText eventTitleEditText;
    private EditText eventDateEditText;
    private EditText eventDescriptionEditText;
    private EditText phoneNumberEditText;

    private int selectedEventId = -1;

    // Store the selected reminder details.
    private String reminderPhone;
    private String reminderTitle;
    private String reminderDate;
    private int reminderEventId = -1;

    // Ask the user for SMS permission.
    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {
                        if (isGranted) {
                            showMessage("SMS permission granted");
                            schedulePendingReminder();
                        } else {
                            showMessage(
                                    "SMS permission denied. Events still work.");
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        databaseHelper = new DatabaseHelper(this);

        eventsGrid = findViewById(R.id.eventsGrid);
        eventTitleEditText =
                findViewById(R.id.eventTitleEditText);
        eventDateEditText =
                findViewById(R.id.eventDateEditText);
        eventDescriptionEditText =
                findViewById(R.id.eventDescriptionEditText);
        phoneNumberEditText =
                findViewById(R.id.phoneNumberEditText);

        Button addButton =
                findViewById(R.id.buttonAddEvent);
        Button updateButton =
                findViewById(R.id.buttonUpdateEvent);
        Button deleteButton =
                findViewById(R.id.buttonDeleteEvent);
        Button smsButton =
                findViewById(R.id.buttonSendReminder);

        eventDateEditText.setFocusable(false);
        eventDateEditText.setOnClickListener(
                v -> showDatePicker());

        addButton.setOnClickListener(v -> addEvent());
        updateButton.setOnClickListener(v -> updateEvent());
        deleteButton.setOnClickListener(v -> deleteEvent());
        smsButton.setOnClickListener(v -> sendEventReminder());

        displayEvents();
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();

        DatePickerDialog picker = new DatePickerDialog(
                this,
                (view, year, month, day) -> {
                    String date = String.format(
                            Locale.US,
                            "%04d-%02d-%02d",
                            year, month + 1, day);
                    eventDateEditText.setText(date);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        picker.show();
    }

    // Add an event to SQLite.
    private void addEvent() {
        String title = eventTitleEditText.getText()
                .toString().trim();
        String date = eventDateEditText.getText()
                .toString().trim();
        String description = eventDescriptionEditText.getText()
                .toString().trim();

        if (title.isEmpty() || date.isEmpty()) {
            showMessage("Please enter an event title and date");
            return;
        }

        boolean success = databaseHelper.addEvent(
                title, date, description);

        if (success) {
            showMessage("Event added successfully");
            clearFields();
            displayEvents();
        } else {
            showMessage("Unable to add event");
        }
    }

    // Update an event and its scheduled reminder.
    private void updateEvent() {
        if (selectedEventId == -1) {
            showMessage("Please select an event first");
            return;
        }

        String title = eventTitleEditText.getText()
                .toString().trim();
        String date = eventDateEditText.getText()
                .toString().trim();
        String description = eventDescriptionEditText.getText()
                .toString().trim();

        if (title.isEmpty() || date.isEmpty()) {
            showMessage("Please enter an event title and date");
            return;
        }

        int eventId = selectedEventId;

        boolean success = databaseHelper.updateEvent(
                eventId, title, date, description);

        if (success) {
            // Cancel the old reminder to prevent incorrect alerts.
            cancelEventReminder(eventId);

            showMessage(
                    "Event updated. Schedule a new reminder if needed.");
            clearFields();
            displayEvents();
        } else {
            showMessage("Unable to update event");
        }
    }

    // Delete an event after confirmation.
    private void deleteEvent() {
        if (selectedEventId == -1) {
            showMessage("Please select an event first");
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Delete Event")
                .setMessage(
                        "Are you sure you want to delete this event?")
                .setPositiveButton("Delete", (dialog, which) -> {

                    int eventId = selectedEventId;

                    boolean success =
                            databaseHelper.deleteEvent(eventId);

                    if (success) {
                        cancelEventReminder(eventId);
                        showMessage("Event deleted successfully");
                        clearFields();
                        displayEvents();
                    } else {
                        showMessage("Unable to delete event");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Show saved events in a two-column grid.
    private void displayEvents() {
        eventsGrid.removeAllViews();
        eventsGrid.setColumnCount(2);

        try (Cursor cursor = databaseHelper.getAllEvents()) {
            while (cursor.moveToNext()) {

                int id = cursor.getInt(
                        cursor.getColumnIndexOrThrow("id"));

                String title = cursor.getString(
                        cursor.getColumnIndexOrThrow("title"));

                String date = cursor.getString(
                        cursor.getColumnIndexOrThrow("event_date"));

                String description = cursor.getString(
                        cursor.getColumnIndexOrThrow("description"));

                TextView eventView = new TextView(this);
                eventView.setText(title + "\n" + date);
                eventView.setTextSize(16);
                eventView.setPadding(16, 20, 16, 20);
                eventView.setBackgroundResource(
                        android.R.drawable.editbox_background);

                GridLayout.LayoutParams params =
                        new GridLayout.LayoutParams();

                params.width = 0;
                params.height =
                        GridLayout.LayoutParams.WRAP_CONTENT;
                params.columnSpec = GridLayout.spec(
                        GridLayout.UNDEFINED, 1f);
                params.setMargins(8, 8, 8, 8);

                eventsGrid.addView(eventView, params);

                eventView.setOnClickListener(v -> {
                    selectedEventId = id;
                    eventTitleEditText.setText(title);
                    eventDateEditText.setText(date);
                    eventDescriptionEditText.setText(description);
                    showMessage("Event selected");
                });
            }
        }
    }

    // User chooses to schedule an SMS reminder.
    private void sendEventReminder() {

        if (selectedEventId == -1) {
            showMessage("Please select a saved event first");
            return;
        }

        reminderPhone = phoneNumberEditText.getText()
                .toString().trim();
        reminderTitle = eventTitleEditText.getText()
                .toString().trim();
        reminderDate = eventDateEditText.getText()
                .toString().trim();
        reminderEventId = selectedEventId;

        if (reminderPhone.isEmpty() ||
                reminderTitle.isEmpty() ||
                reminderDate.isEmpty()) {

            showMessage("Enter a phone number and event details");
            return;
        }

        // Ask for permission if not already granted.
        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            smsPermissionLauncher.launch(
                    Manifest.permission.SEND_SMS);
            return;
        }

        schedulePendingReminder();
    }

    private void schedulePendingReminder() {

        if (reminderEventId == -1 ||
                reminderPhone == null ||
                reminderTitle == null ||
                reminderDate == null) {
            return;
        }

        scheduleEventReminder(
                reminderEventId,
                reminderPhone,
                reminderTitle,
                reminderDate);
    }

    // Schedule SMS one day before the event at 9 AM.
    private void scheduleEventReminder(
            int eventId,
            String phoneNumber,
            String eventTitle,
            String eventDate) {

        try {
            SimpleDateFormat format =
                    new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            format.setLenient(false);

            Date date = format.parse(eventDate);

            if (date == null) {
                showMessage("Invalid event date");
                return;
            }

            Calendar reminderTime = Calendar.getInstance();
            reminderTime.setTime(date);
            reminderTime.add(Calendar.DAY_OF_MONTH, -1);
            reminderTime.set(Calendar.HOUR_OF_DAY, 9);
            reminderTime.set(Calendar.MINUTE, 0);
            reminderTime.set(Calendar.SECOND, 0);
            reminderTime.set(Calendar.MILLISECOND, 0);

            if (reminderTime.getTimeInMillis()
                    <= System.currentTimeMillis()) {
                showMessage("Reminder time has already passed");
                return;
            }

            AlarmManager alarmManager =
                    (AlarmManager) getSystemService(
                            Context.ALARM_SERVICE);

            if (alarmManager == null) {
                showMessage("Alarm service unavailable");
                return;
            }

            // Exact alarms require additional access on Android 12+.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    && !alarmManager.canScheduleExactAlarms()) {

                new AlertDialog.Builder(this)
                        .setTitle("Allow Exact Reminders")
                        .setMessage(
                                "Please allow alarms and reminders " +
                                        "in Settings to schedule SMS at 9 AM.")
                        .setPositiveButton("Open Settings",
                                (dialog, which) -> {
                                    Intent settingsIntent =
                                            new Intent(
                                                    Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                                    settingsIntent.setData(
                                            Uri.parse(
                                                    "package:" + getPackageName()));
                                    startActivity(settingsIntent);
                                })
                        .setNegativeButton("Cancel", null)
                        .show();
                return;
            }

            Intent intent = new Intent(
                    this, EventReminderReceiver.class);

            intent.putExtra("phoneNumber", phoneNumber);
            intent.putExtra("eventTitle", eventTitle);
            intent.putExtra("eventDate", eventDate);

            PendingIntent pendingIntent =
                    PendingIntent.getBroadcast(
                            this,
                            eventId,
                            intent,
                            PendingIntent.FLAG_UPDATE_CURRENT
                                    | PendingIntent.FLAG_IMMUTABLE);

            alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    reminderTime.getTimeInMillis(),
                    pendingIntent);

            showMessage(
                    "SMS reminder scheduled for the day before at 9 AM");

        } catch (ParseException exception) {
            showMessage("Invalid event date");
        } catch (SecurityException exception) {
            showMessage("Alarm permission unavailable");
        }
    }

    // Cancel an alarm when an event is updated or deleted.
    private void cancelEventReminder(int eventId) {

        Intent intent = new Intent(
                this, EventReminderReceiver.class);

        PendingIntent pendingIntent =
                PendingIntent.getBroadcast(
                        this,
                        eventId,
                        intent,
                        PendingIntent.FLAG_NO_CREATE
                                | PendingIntent.FLAG_IMMUTABLE);

        if (pendingIntent != null) {

            AlarmManager alarmManager =
                    (AlarmManager) getSystemService(
                            Context.ALARM_SERVICE);

            if (alarmManager != null) {
                alarmManager.cancel(pendingIntent);
            }

            pendingIntent.cancel();
        }
    }

    private void clearFields() {
        selectedEventId = -1;
        eventTitleEditText.setText("");
        eventDateEditText.setText("");
        eventDescriptionEditText.setText("");
    }

    private void showMessage(String message) {
        Toast.makeText(
                this, message, Toast.LENGTH_SHORT).show();
    }
}
