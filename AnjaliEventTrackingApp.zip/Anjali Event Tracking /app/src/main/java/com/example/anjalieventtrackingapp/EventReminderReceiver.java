package com.example.anjalieventtrackingapp;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.core.content.ContextCompat;

public class EventReminderReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        String phoneNumber =
                intent.getStringExtra("phoneNumber");

        String eventTitle =
                intent.getStringExtra("eventTitle");

        String eventDate =
                intent.getStringExtra("eventDate");

        // Do not send SMS without permission.
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            Log.d("EventReminder",
                    "SMS permission denied. Reminder skipped.");
            return;
        }

        // Check the reminder information.
        if (phoneNumber == null ||
                phoneNumber.trim().isEmpty() ||
                eventTitle == null ||
                eventDate == null) {

            Log.d("EventReminder",
                    "Missing reminder information.");
            return;
        }

        String message = "Event Reminder: " +
                eventTitle + " is scheduled for " + eventDate;

        try {
            SmsManager smsManager =
                    context.getSystemService(SmsManager.class);

            if (smsManager != null) {
                smsManager.sendTextMessage(
                        phoneNumber,
                        null,
                        message,
                        null,
                        null);

                Log.d("EventReminder",
                        "SMS send request submitted.");
            }

        } catch (Exception exception) {
            Log.e("EventReminder",
                    "Unable to send SMS reminder.",
                    exception);
        }
    }
}

