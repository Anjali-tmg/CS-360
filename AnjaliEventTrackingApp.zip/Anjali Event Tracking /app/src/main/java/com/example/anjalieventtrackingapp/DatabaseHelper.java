package com.example.anjalieventtrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "EventTracker.db";
    private static final int DATABASE_VERSION = 1;

    private static final String USERS_TABLE = "users";
    private static final String EVENTS_TABLE = "events";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create a table for user accounts.
        db.execSQL("CREATE TABLE " + USERS_TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password_hash TEXT NOT NULL, " +
                "password_salt TEXT NOT NULL)");

        // Create a table for event information.
        db.execSQL("CREATE TABLE " + EVENTS_TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "title TEXT NOT NULL, " +
                "event_date TEXT NOT NULL, " +
                "description TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        // Future database upgrades will be handled here.
    }

    // Convert a byte array to hexadecimal text.
    private String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();

        for (byte value : bytes) {
            result.append(String.format("%02x", value & 0xff));
        }

        return result.toString();
    }

    // Convert hexadecimal text back to bytes.
    private byte[] hexToBytes(String hex) {
        byte[] result = new byte[hex.length() / 2];

        for (int i = 0; i < result.length; i++) {
            int position = i * 2;
            result[i] = (byte) Integer.parseInt(
                    hex.substring(position, position + 2), 16);
        }

        return result;
    }

    // Protect passwords using a random salt and hashing.
    private String hashPassword(String password, byte[] salt) {
        PBEKeySpec spec = new PBEKeySpec(
                password.toCharArray(), salt, 120000, 256);

        try {
            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance(
                            "PBKDF2WithHmacSHA1");

            return bytesToHex(factory.generateSecret(spec)
                    .getEncoded());

        } catch (Exception exception) {
            throw new IllegalStateException(
                    "Unable to hash password", exception);
        } finally {
            spec.clearPassword();
        }
    }

    // Save a new user account.
    public boolean addUser(String username, String password) {

        if (username.trim().isEmpty() || password.isEmpty()) {
            return false;
        }

        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);

        ContentValues values = new ContentValues();
        values.put("username", username.trim());
        values.put("password_hash",
                hashPassword(password, salt));
        values.put("password_salt", bytesToHex(salt));

        SQLiteDatabase db = getWritableDatabase();

        long result = db.insertWithOnConflict(
                USERS_TABLE, null, values,
                SQLiteDatabase.CONFLICT_IGNORE);

        return result != -1;
    }

    // Check whether the login information is correct.
    public boolean checkUser(String username, String password) {

        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(
                USERS_TABLE,
                new String[]{"password_hash", "password_salt"},
                "username = ?",
                new String[]{username},
                null, null, null)) {

            if (!cursor.moveToFirst()) {
                return false;
            }

            String savedHash = cursor.getString(0);
            String savedSalt = cursor.getString(1);

            String enteredHash = hashPassword(
                    password, hexToBytes(savedSalt));

            return MessageDigest.isEqual(
                    hexToBytes(savedHash),
                    hexToBytes(enteredHash));
        }
    }

    // Add a new event to the database.
    public boolean addEvent(String title, String date,
                            String description) {

        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("event_date", date);
        values.put("description", description);

        long result = getWritableDatabase().insert(
                EVENTS_TABLE, null, values);

        return result != -1;
    }

    // Retrieve all events from the database.
    public Cursor getAllEvents() {

        return getReadableDatabase().query(
                EVENTS_TABLE, null, null, null,
                null, null, "event_date ASC");
    }

    // Update an existing event.
    public boolean updateEvent(int id, String title,
                               String date, String description) {

        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("event_date", date);
        values.put("description", description);

        int rows = getWritableDatabase().update(
                EVENTS_TABLE, values, "id = ?",
                new String[]{String.valueOf(id)});

        return rows > 0;
    }

    // Delete an event from the database.
    public boolean deleteEvent(int id) {

        int rows = getWritableDatabase().delete(
                EVENTS_TABLE, "id = ?",
                new String[]{String.valueOf(id)});

        return rows > 0;
    }
}
